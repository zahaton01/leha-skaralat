
<div class="mt-5 block-cta-1 primary-overlay" style="background-image: url('images/hero_bg_2.jpg')">
    <div class="container">
        <div class="row align-items-center justify-content-between">
            <div class="col-lg-7 mb-4 mb-lg-0">
                <h2 class="mb-3 mt-0 text-white">Скидка 30% на первую покупку</h2>
                <p class="mb-0 text-white lead">Хотите получить лучшие практики тетахилинга в постоянное исспользование? Тогда я жду вас!</p>
            </div>
            <div class="col-lg-4">
                <p class="mb-0"><a href="contact.html" class="btn btn-outline-white text-white btn-md btn-pill px-5 font-weight-bold btn-block">Получить доступ</a></p>
            </div>
        </div>
    </div>
</div>
