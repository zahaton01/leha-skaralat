<div class="site-section">
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-12 text-center">
                <h2 class="site-section-heading text-center font-secondary">Happy Customers</h2>
            </div>
        </div>
        <div class="row">

            <div class="col-12">

                <div class="owl-carousel-2 owl-carousel">

                    <div class="d-block block-testimony mx-auto text-center">
                        <div class="person w-25 mx-auto mb-4">
                            <img src="images/person_1.jpg" alt="Image" class="img-fluid rounded-circle w-50 mx-auto">
                        </div>
                        <div>
                            <h2 class="h5 mb-4">Аноним</h2>
                            <blockquote>&ldquo;Это было нереально круто! Сеанс оправдал самые смелые ожидания!&rdquo;</blockquote>
                        </div>
                    </div>

                    <div class="d-block block-testimony mx-auto text-center">
                        <div class="person w-25 mx-auto mb-4">
                            <img src="images/person_2.jpg" alt="Image" class="img-fluid rounded-circle w-50 mx-auto">
                        </div>
                        <div>
                            <h2 class="h5 mb-4">Аноним</h2>
                            <blockquote>&ldquo;Жена заставила купить и курс и я в шоке! У меня теперь новый автомобиль и долгожданный ребенок!&rdquo;</blockquote>
                        </div>
                    </div>

                    <div class="d-block block-testimony mx-auto text-center">
                        <div class="person w-25 mx-auto mb-4">
                            <img src="images/person_3.jpg" alt="Image" class="img-fluid rounded-circle w-50 mx-auto">
                        </div>
                        <div>
                            <h2 class="h5 mb-4">Аноним</h2>
                            <blockquote>&ldquo;От меня ушел муж и 3 года не давал о себе забыть. Настя помогла наконец-то обрести новую любовь (а я стеснялся, что гей).&rdquo;</blockquote>
                        </div>
                    </div>

                    <div class="d-block block-testimony mx-auto text-center">
                        <div class="person w-25 mx-auto mb-4">
                            <img src="images/person_1.jpg" alt="Image" class="img-fluid rounded-circle w-50 mx-auto">
                        </div>
                        <div>
                            <h2 class="h5 mb-4">Аноним</h2>
                            <blockquote>&ldquo;Всю жизнь вела себя как пацанка. Наконец-то я раскрыла свою сексуальность и преобразилась на глазах!&rdquo;</blockquote>
                        </div>
                    </div>


                </div>
            </div>


        </div>
    </div>
</div>