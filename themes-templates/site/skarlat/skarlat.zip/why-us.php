<div class="block-half-content-1 d-block d-lg-flex mt-5">
    <div class="block-half-content-img" style="background-image: url('images/hero_bg_1.jpg')">

    </div>
    <div class="block-half-content-text bg-primary">
        <div class="block-half-content-text-inner">
            <h2 class="block-half-content-heading mb-4">Почему Я?</h2>
            <div class="block-half-content-excerpt">
                <!--          <p class="lead">Опытный тетахилер и биолог, международные сертификаты и отзывы клиентов!</p>-->
            </div>
        </div>

        <div class="block-counter-1 section-counter">
            <div class="row">
                <div class="col-sm-4">
                    <div class="counter">
                        <div class="number-wrap">
                            <span class="block-counter-1-number" data-number="87">84</span><span class="append"></span>
                        </div>
                        <span class="block-counter-1-caption">Клиентов</span>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="counter">
                        <div class="number-wrap">
                            <span class="block-counter-1-number" data-number="99">65</span><span class="append
">%</span>
                        </div>
                        <span class="block-counter-1-caption">Успеха</span>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="counter">
                        <div class="number-wrap">
                            <span class="block-counter-1-number" data-number="300">100</span><span class="append">%</span>
                        </div>
                        <span class="block-counter-1-caption">Безопасность</span>
                    </div>
                </div>
            </div>
        </div>
    </div>